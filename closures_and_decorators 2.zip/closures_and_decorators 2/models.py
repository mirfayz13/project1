import enum


class TodoType(enum.Enum):
    SHOPPING = 'SHOPPING'
    PERSONAL = 'PERSONAL'
    LEARN = 'LEARN'


class UserStatus(enum.Enum):
    INACTIVE = 'INACTIVE'
    ACTIVE = 'ACTIVE'
    BLOCKED = 'BLOCKED'


class UserRole(enum.Enum):
    SUPER_ADMIN = 'SUPER_ADMIN'
    USER = 'USER'
    ADMIN = 'ADMIN'


class User:
    def __init__(self,
                 username: str,
                 password: str,
                 user_id: int | None = None,
                 role: UserRole | None = None,
                 status: UserStatus | None = None,
                 login_try_count: int | None = None
                 ):
        self.id = user_id
        self.username = username
        self.password = password
        self.role = role or UserRole.USER.value
        self.status = status or UserStatus.INACTIVE.value
        self.login_try_count = login_try_count or 0

    @staticmethod
    def from_tuple(args: tuple):
        return User(user_id=args[0],
                    username=args[1],
                    password=args[2],
                    role=args[3],
                    status=args[4],
                    login_try_count=args[5])

    def __repr__(self) -> str:
        return f'{self.id} - {self.username} - {self.role}'


class Todo:
    def __init__(self,
                 title: str,
                 user_id: int,
                 todo_id: int | None = None,
                 todo_type: TodoType | None = None,
                 ):
        self.id = todo_id
        self.title = title
        self.user_id = user_id
        self.todo_type = todo_type or TodoType.PERSONAL.value

    def __repr__(self) -> str:
        return f'{self.id} - {self.title} - {self.user_id}'


class UserList:
    def __init__(self):
        self.users = []

    def create(self, username: str, password: str, role: UserRole = None, status: UserStatus = None, login_try_count: int = None) -> User:
        user_id = len(self.users) + 1
        user = User(username, password, user_id, role, status, login_try_count)
        self.users.append(user)
        return user

    def read(self, user_id: int) -> User:
        for user in self.users:
            if user.id == user_id:
                return user
        return None

    def update(self, user_id: int, username: str = None, password: str = None, role: UserRole = None, status: UserStatus = None, login_try_count: int = None) -> User:
        user = self.read(user_id)
        if user:
            if username is not None:
                user.username = username
            if password is not None:
                user.password = password
            if role is not None:
                user.role = role
            if status is not None:
                user.status = status
            if login_try_count is not None:
                user.login_try_count = login_try_count
        return user

    def delete(self, user_id: int) -> bool:
        user = self.read(user_id)
        if user:
            self.users.remove(user)
            return True
        return False

user_list = UserList()
user1 = user_list.create("john_doe", "password123", role=UserRole.USER, status=UserStatus.ACTIVE)

print(user_list.read(1))  

user_list.update(1, password="newpassword")

print(user_list.read(1))  

user_list.delete(1)

print(user_list.read(1)) 